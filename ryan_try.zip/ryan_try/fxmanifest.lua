fx_version 'cerulean'
game 'gta5'

author 'Ryan Hard'
description 'Try Command'
version '1.0.0'

server_scripts {
    'server.lua'
}

client_scripts {
    'client.lua'
}

dependencies {
    'qb-core'
}
